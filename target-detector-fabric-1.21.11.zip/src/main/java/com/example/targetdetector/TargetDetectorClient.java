package com.example.targetdetector;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class TargetDetectorClient implements ClientModInitializer {
    private static final double RANGE = 4.0;
    private static final long COOLDOWN_MS = 1600L;
    private long lastReady = 0L;

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register(this::renderHud);
    }

    private void renderHud(DrawContext ctx, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        HitResult hit = client.crosshairTarget;
        Entity target = null;
        double distance = -1;

        if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity living
                && ehr.getEntity() != client.player) {
            target = living;
            distance = client.player.distanceTo(target);
        }

        int x = 8;
        int y = 8;

        if (target != null && distance <= RANGE) {
            long now = System.currentTimeMillis();
            if (now - lastReady >= COOLDOWN_MS) {
                client.textRenderer.draw(ctx, Text.literal(
                        "Target: " + target.getName().getString() +
                        "  Distance: " + String.format("%.2f", distance) +
                        "  ATTACK READY (simulated)"),
                        x, y, 0xFFFFFF);
            } else {
                double remaining = (COOLDOWN_MS - (now - lastReady)) / 1000.0;
                client.textRenderer.draw(ctx, Text.literal(
                        "Target: " + target.getName().getString() +
                        "  Distance: " + String.format("%.2f", distance) +
                        "  Cooldown: " + String.format("%.2f", remaining) + "s"),
                        x, y, 0xFFFFFF);
            }
        } else {
            client.textRenderer.draw(ctx, Text.literal(
                    "Target: none / out of 4 blocks"), x, y, 0xFFFFFF);
        }
    }
}
